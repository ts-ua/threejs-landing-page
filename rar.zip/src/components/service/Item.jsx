import { Html, Plane } from '@react-three/drei';
import { Canvas } from '@react-three/fiber';
import React, { useEffect } from 'react';

const Item = ({ src, width, height }) => {

    useEffect(() => {

    },)

    return (

    )
}

export default Item;